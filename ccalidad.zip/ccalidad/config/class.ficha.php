<?php
class FICHA
{
    private $db;
 
    function __construct($DB_con)
    {
      $this->db = $DB_con;
    }
 
 
  public function getAllCategorias()
    {
       try
       {
          $stmt = $this->db->prepare("SELECT * FROM tbl_categoria ORDER BY posicion");
          
          $stmt->execute();
          
          $result = $stmt->fetchAll();

          return $result;
       }
       catch(PDOException $e)
       {
           echo $e->getMessage();
       }
   }



public function getAllItems($categoria)
    {
       try
       {
          $stmt = $this->db->prepare("SELECT * FROM tbl_items WHERE id_categoria=". $categoria ." ORDER BY id");
          
          $stmt->execute();
          
          $result = $stmt->fetchAll();

          return $result;
       }
       catch(PDOException $e)
       {
           echo $e->getMessage();
       }
   }


    public function registerFicha($idLocal,$fecha,$obs,$plazo,$idusuario)
    {
       try
       {
          
           $stmt = $this->db->prepare("INSERT INTO  tbl_ficha (	id_tienda,fecha_inspeccion,plazo,observaciones,id_usuario) 
                                                       VALUES(:idlocal, :fecha, :plazo,:obs,:idusuario)");
           $stmt->bindparam(":idlocal", $idLocal);
           $stmt->bindparam(":fecha", $fecha);
           $stmt->bindparam(":plazo", $plazo);
           $stmt->bindparam(":obs", $obs);
           $stmt->bindparam(":idusuario", $idusuario);            
           $stmt->execute(); 
           
           return $this->db->lastInsertId().'<br />';
          
       }
       catch(PDOException $e)
       {
           echo $e->getMessage();
       }    
    }
 
   
     public function searchByLocal($idLocal,$inspector,$idCategoria,$item,$valor,$fechaInicio,$fechaFin)
    {
       try
       {

	      $local = "";
		  $categoria = "";
		  $valor1="";
 $item1="";
		  $inspector1="";
		  
          if($idLocal!="T"){
				$local = " ficha.id_tienda = ".$idLocal ." AND ";
	       }
	   
	      if($idCategoria!="T"){
				$categoria =" id_categoria = ". $idCategoria ." AND ";
	      }
		  
		  if($valor!="T"){
				$valor1 =" valor = ". $valor ." AND ";
	      }
		  
		  if($inspector!="T"){
				$inspector1 = " user.user_id =" . $inspector ." AND ";
	      }
		 
 if($item!="T"){
				$item1= " id_item =" . $item." AND ";
	      } 
		  




		  $sql = "SELECT ficha.id,ficha.fecha_inspeccion,ficha.observaciones, tienda.tienda,tienda.pasillo, user.user_name ,id_item,id_categoria,valor ";
		  $sql .= " FROM tbl_ficha as ficha INNER JOIN tbl_tiendas as tienda ON ficha.id_tienda = tienda.id INNER JOIN tbl_users as user ON ";
		  $sql .= " ficha.id_usuario = user.user_id INNER JOIN tbl_resultado as resultado ON ficha.id = resultado.id_ficha WHERE ". $local ;
		  $sql .= $categoria . "  ". $valor1 ." ". $inspector1 ." ". $item1 ." ficha.fecha_inspeccion BETWEEN :start_date AND :end_date";
		  
		  $stmt = $this->db->prepare($sql);

           //echo "Valor ".$idLocal."-".$idCategoria."-".$valor."-". $inspector ." - ". $fechaInicio."-".$fechaFin . "<br>";

           //var_dump($stmt);
          
          $stmt->execute(array(':start_date'=>$fechaInicio, ':end_date'=>$fechaFin));
          
          $result = $stmt->fetchAll();

          return $result;
       }
       catch(PDOException $e)
       {
           echo $e->getMessage();
       }
   }
   
    public function searchResultadosFicha($idFicha)
    {  $valor="";
       try
       {
          $stmt = $this->db->prepare("SELECT *  FROM tbl_resultado WHERE id_ficha=:idficha ORDER BY id_item");
           //var_dump($stmt);
          
          $stmt->execute(array(':idficha'=>$idFicha));
          $stmt->fetch(PDO::FETCH_ASSOC);
          $result = $stmt->fetchAll();
          foreach($result as $row){
                $valor.=$row['valor'].",";
              
          }              	       
          return $valor;
       }
       catch(PDOException $e)
       {
           echo $e->getMessage();
       }
   }

   /*public function notificacionFicha($idFicha,$idCat)
    {  $valor="";
       try
       {
          $stmt = $this->db->prepare("SELECT Count(valor) AS Number FROM tbl_resultado WHERE id_ficha = :idficha AND id_categoria = :id_cat AND valor=0");
           //var_dump($stmt);
          
          $stmt->execute(array(':idficha'=>$idFicha, :idcat'=>$idCat));
          $stmt->fetch(PDO::FETCH_ASSOC);
          $result = $stmt->fetchAll();
          foreach($result as $row){
                $valor.=$row['valor'].",";
              
          }              	       
          return $valor;
       }
       catch(PDOException $e)
       {
           echo $e->getMessage();
       }
   }*/
   
   
   
   
   
   
 
}
?>